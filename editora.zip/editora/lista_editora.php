<div class="container">
  <h2>Editora</h2>
      <a class="btn btn-primary" href="inserir.php">Novo</a>
  <?php if (count($registros)==0): ?>
    <p>Nenhum registro encontrado.</p>
  <?php else: ?>
    <table class="table table-hover table-stripped">
      <thead>
          <th>#</th>
          <th>Nome</th>
          <th>Categoria</th>
          <th>Ações</th>
      </thead>
      <tbody>
        <?php foreach ($registros as $linha): ?>
          <tr>
            <td><?php echo $linha['id']; ?></td>
            <td><?php echo $linha['nome']; ?></td>
            <td><?php echo $linha['categoria']; ?></td>
            <td>
                <a class="btn btn-warning btn-sm" href="editora.php?acao=buscar&id=<?php echo $linha['id']; ?>">Editar</a>
                <a class="btn btn-danger btn-sm" href="editora.php?acao=excluir&id=<?php echo $linha['id']; ?>">Excluir</a>
                <a href="gerarPDF.php" target="_blank">Gerar relatório PDF</a>

            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
