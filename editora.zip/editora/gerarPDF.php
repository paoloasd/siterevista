
<?php

include './fpdf/fpdf.php';

$sql= "SELECT * FROM editora ORDER BY id ASC";

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(190,10,utf8_decode('Relatório de Editoras'),0,0,"C");
$pdf->Ln(15);

$pdf->SetFont("Arial","I",14);
$pdf->Cell(20,7,"ID",1,0,"C");
$pdf->Cell(80,7,"Nome",1,0,"C");
$pdf->Cell(80,7,"Categoria",1,0,"C");
$pdf->Ln();

foreach ($sql as $editora){
    $pdf->Cell(20,7,$editora["id"],1,0,"C");
    $pdf->Cell(80,7,utf8_decode($editora["nome"]),1,0,"C");
    $pdf->Cell(80,7,utf8_decode($editora["categoria"]),1,0,"C");
    $pdf->Ln();
}

$pdf->Output();
