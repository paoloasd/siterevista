<?php
    if(isset($registro)) $acao = "editora.php?acao=atualizar&id=".$registro['id'];
    else $acao = "editora.php?acao=gravar";
 ?>
<div class="container">
  <form class=""  action="editora.php" method="post">
    <div class="from-group">
      <label for="nome">Nome</label>
      <input id="nome" class="form-control" type="text" name="nome"
        value="<?php if(isset($registro)) echo $registro['nome']; ?>" required>
    </div>
    <div class="from-group">
      <label for="categoria">Categoria</label>
      <input id="categoria" class="form-control" type="text" name="categoria"
        value="<?php if(isset($registro)) echo $registro['categoria']; ?>" required>
    </div>
    <br>
    <button class="btn btn-info" type="submit" type="submit" value="Enviar" name="Enviar">Enviar</button>

  </form>
</div>
